window.mustache_list = ["popup", "schedulewrap", "speaker", "table"];
